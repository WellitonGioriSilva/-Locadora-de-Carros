function somarValores()
{
    var n1 = parseFloat (numero1.value);
    var n2 = parseFloat (numero2.value);
    var soma = n1+n2;
    resultado.value = soma;
}